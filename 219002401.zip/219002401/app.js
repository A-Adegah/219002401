const express = require('express');
const mongoose = require('mongoose');
const {MongoClient} = require('mongodb');

const app = express();

let db;
let todo;

const client = MongoClient.connect("mongodb://localhost:27017/employeedb", 
{ useUnifiedTopology: true }, (error, client)=>{
    if(!error){
      console.log("DB Connected");
       db = client.db('employeedb')
       todo = db.collection('todo')
    } else{
      console.log("DB not connected")
    }
});


app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));

  const employees = [
    {
        _id: "5e9640feaf62fa7fa1157fe8",
        isActive: false,
        picture: "/images/freedom.jpg",
        age: 33,
        name: "Freedom Gomes",
        position: " Director General",
        email: "freedom.gomes@undefined.net",
        phone: "+233 (024) 467-3459",
        address: "Box MA619 Roman Street, Madina, Block 5988",
        about: "Proident irure deserunt commodo laborum excepteur duis sint ex nisi irure commodo sint voluptate in. Qui velit id occaecat nostrud culpa ipsum. Proident consectetur id amet Lorem cupidatat. Do laboris amet consequat nulla incididunt minim nulla consequat aliqua.",
        date_hired: "Friday, April 18, 2014 3:42 PM"
      },
      {
        _id: "5e9640fe5e6f790c040c179a",
        isActive: false,
        picture: "/images/florence.jpg",
        age: 23,
        name: "Florence Asare",
        position: "Data Entry",
        email: "florence.Asare@undefined.com",
        phone: "+233 (027) 4082130",
        address: "Box AN175 legon Place, East Legon, Block 769",
        date_hired: "Thursday, February 6, 2020 7:05 AM"
      },
      {
        _id: "5e9640fe78e6d4999ed266ef",
        isActive: false,
        picture: "/images/linda.jpg",
        age: 28,
        name:"Linda Walter",
        position: "Network Administrator",
        email: "linda.walter@undefined.co.uk",
        phone: "+233 (026) 4713663",
        address: "Box ST687 gyan Street, American house,Block 7853",
        date_hired: "Tuesday, January 8, 2019 7:16 AM"
      },
      {
        _id: "5e9640fe18d159438798d556",
        isActive: false,
        picture: "/images/Luther.jpg",
        age: 27,
        name: "Luther Junior Jack",
        position: "Web Developer",
        email: "luther.rich@undefined.ca",
        phone: "+233 (024) 5922580",
        address: "826 Interborough Parkway, Belva, District Of Columbia, 8248",
       date_hired: "Sunday, Aug 25, 2015 1:14 PM"
      },
      {
        _id: "5e9640fe521ac49fe6d8682a",
        isActive: false,
        picture: "/images/Lopez.jpg",
        age: 21,
        name: "Lopez Steven",
        position: "Accountant",
        email: "lopez.stevens@undefined.tv",
        phone: "+233 (020) 4152869",
        address: "Box TN934 moco street, Accra, Block 973",
        date_hired: "Saturday, September 27, 2016 11:54 AM"
      }
]

app.get('/', (req, res)=>{
  res.render('home')
});

app.get('/employees', async(req, res)=>{
  const todolist = await todo.find({}).toArray();
    console.table(todolist)
    res.render('employeeList', {
      employees
  })
});

app.get('/todolist', async(req, res)=>{
  const result = await todo.find({}).toArray()
  console.table(result)
  // res.redirect('/todolist');
  res.render('todo',{result} )
});

app.post('/todolist', async (req, res)=>{
    let data = {
      fName : req.body.fName, 
      lName:req.body.lName, 
      position:req.body.position,
      todo: req.body.todo
      };

    const result = await todo.insertOne(data);
    res.redirect('/todolist');
});

const port = 9000;
app.listen(port, ()=>{
    console.log("Running on port " + port)
});